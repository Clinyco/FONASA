#!/usr/bin/env bash
set -euo pipefail

# Uso: clean-nasser.sh <ruta_proyecto> "<TEXTO_HERO>"
PROJ="${1:-}"
HERO_TEXT="${2:-}"

if [ -z "${PROJ}" ] || [ -z "${HERO_TEXT}" ]; then
  echo "Uso: clean-nasser.sh <ruta_proyecto> "<TEXTO_HERO>""
  exit 1
fi

if [ ! -d "${PROJ}" ]; then
  echo "Ruta no válida: ${PROJ}"; exit 1
fi

echo "-> Eliminando materiales del Dr. Nasser (Eluzen/Eluzem) si existen..."
pushd "${PROJ}" >/dev/null

# Buscar y borrar imágenes conocidas
shopt -s nullglob nocaseglob
for f in assets/*Nasser*.webp assets/*Nasser*.png assets/*Nasser*.jpg assets/*Nasser*.jpeg; do
  echo "   borrando ${f}"
  rm -f "${f}" || true
done
shopt -u nocaseglob

# Quitar referencias textuales (comentarios y líneas con su nombre)
# (hace copia de seguridad .bak por si acaso)
grep -RIl --include='*.{html,htm,js,jsx,ts,tsx,vue,svelte,css,scss,md}' -e 'Nasser' -e 'Eluzen' -e 'Eluzem' -e 'Cirujano Bari' . | while read -r file; do
  sed -i.bak '/Nasser/d;/Eluzen/d;/Eluzem/d;/Cirujano Bari/d' "$file" || true
done

echo "-> Intentando localizar HERO para insertar el nuevo texto (no destructivo)..."
# Estrategia: si existe un elemento con id=hero o class=hero, intenta insertar un div con el texto.
CAND=$(grep -RIl --include='*.{html,htm,js,jsx,ts,tsx,vue,svelte}' -e 'id=["\']hero["\']' -e 'class=["\']hero["\']' . | head -n 1 || true)
if [ -n "${CAND}" ]; then
  if ! grep -q "hero-overlay" "${CAND}"; then
    echo "   Insertando overlay en ${CAND}"
    # Inserta un bloque simple antes del cierre de </section> o </div> cercano
    perl -0777 -pe 's#(</section>|</div>)#<div class="hero-overlay">'"${HERO_TEXT//\//\/}"'</div>\n\1#i' -i.bak "${CAND}" || true
    # Añade estilos mínimos (si existe main.css o styles.css)
    for css in src/styles.css src/main.css styles.css public/styles.css; do
      if [ -f "$css" ]; then
        cat >> "$css" <<'CSS'
.hero { position: relative; }
.hero .hero-overlay {
  position: absolute; inset: 0; display: grid; place-items: center;
  padding: 1.25rem; text-align: center; font-weight: 600;
  font-size: clamp(1rem, 2vw, 1.25rem);
}
CSS
        break
      fi
    done
  fi
else
  echo "   No se detectó hero automáticamente. Edita manualmente el copy con el texto solicitado."
fi

popd >/dev/null
