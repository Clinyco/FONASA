#!/usr/bin/env bash
set -euo pipefail

# Uso: update-menu.sh <ruta_repo_sitio>
SITE="${1:-}"
if [ -z "${SITE}" ] || [ ! -d "${SITE}" ]; then
  echo "Uso: update-menu.sh <ruta_repo_sitio>"; exit 0
fi

echo "-> Buscando navegación para cambiar CONTACTO -> Calculadora PAD (/calculadora/)"
pushd "${SITE}" >/dev/null

# Cambia texto 'Contacto/CONTACTO' por 'Calculadora PAD' y apunta href a /calculadora/
# Opera sólo en archivos HTML/JS/TSX/Vue para evitar tocar contenido no deseado.
grep -RIl --include='*.{html,htm,js,jsx,ts,tsx,vue}' -e 'CONTACTO' -e 'Contacto' -e 'contacto' . | while read -r f; do
  # reemplaza texto visible
  sed -i.bak 's/>\s*CONTACTO\s*</>Calculadora PAD</g;s/>\s*Contacto\s*</>Calculadora PAD</g;s/>\s*contacto\s*</>Calculadora PAD</g' "$f" || true
  # reemplaza links comunes a contacto hacia /calculadora/
  sed -i.bak 's/href=["\'\']\/?contacto\/?["\'\']/href="\/calculadora\/"/g' "$f" || true
done

popd >/dev/null
