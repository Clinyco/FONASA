# FONASA / FONASAPAD — Fusión por **subdirectorio** `/calculadora/` (Opción B)

Este kit te permite **fusionar** la calculadora (repo `fonasa`) con el sitio principal (`fonasapad`) a nivel de **dominio** usando un **proxy por subdirectorio**:
- La calculadora se compila localmente con base **`/calculadora/`** y se **despliega a Netlify**.
- Cloudflare Worker enruta `https://fonasapad.cl/calculadora/*` → (tu sitio Netlify de la calculadora).
- Se reemplaza el texto del *hero* y se elimina todo material del **Dr. Nasser** (Eluzen/Eluzem).
- (Opcional) Se actualiza el **menú** del repo `fonasapad` cambiando “CONTACTO” → “Calculadora PAD” (`/calculadora/`).

> **No** se mezclan códigos en un solo build; es una **integración limpia** por subdirectorio (mejor para SEO/analítica unificadas) y facilita el mantenimiento.

---

## Requisitos

- macOS con **Node 18+**, **npm**, **git**, y **bash**.
- **Netlify CLI** (el script la instalará si falta).
- (Opcional) **Cloudflare** + **Wrangler** para publicar el Worker (puedes hacerlo desde dashboard).

---

## Variables (edita `.env` o pasa flags)

Copia `.env.example` a `.env` y ajusta si es necesario:

```
CALC_REPO_GIT=git@github.com:Clinyco/fonasa.git
SITE_REPO_GIT=git@github.com:Clinyco/fonasapad.git
CALC_BRANCH=main
SITE_BRANCH=main

# Nombre opcional del sitio en Netlify (si no existe, netlify init te guía)
NETLIFY_SITE_NAME=fonasapad-calculadora

# Texto exacto que me indicaste (se puede ajustar aquí si lo cambias a futuro)
HERO_TEXT=Trastorno músculo-esquelético que por dolor crónico requiera una perdida de peso significativa para resolver el dolor o llevar a cabo la cirugía protésica.
```

---

## **Un solo paso**

```bash
cd scripts
bash one-step-merge-and-deploy.sh
```

El script hará:
1. Clonar `fonasa` y `fonasapad` en `./work/` (branches por defecto `main`).  
2. Detectar el **stack** de la calculadora y ajustar el **base path** a `/calculadora/`.  
3. Reemplazar el **hero** con el texto configurado y **eliminar** materiales del Dr. Nasser.  
4. Compilar la calculadora (genera **dist/** o **build/**).  
5. Asegurar `netlify/_redirects` en la carpeta de build.  
6. **Desplegar** a Netlify (draft y opción de prod).  
7. (Opcional) Actualizar **menú** del repo `fonasapad` (CONTACTO → Calculadora PAD → `/calculadora/`).  
8. Mostrar un resumen con la URL de Netlify y recordatorio para publicar el **Worker**.

---

## Publicar el **Cloudflare Worker**

1. Abre `cloudflare/worker-calculadora.js` y **reemplaza**:
   ```js
   const UPSTREAM = 'https://<TU-SITIO-NETLIFY>.netlify.app';
   ```
   por el dominio de tu sitio Netlify de la calculadora.

2. (Con Wrangler) editando `cloudflare/wrangler.toml` o desde el Dashboard:
   - **Route**: `fonasapad.cl/calculadora*`
   - Publica el Worker.

> El Worker solo intercepta `/calculadora*` y pasa el resto al sitio principal sin tocarlo.

---

## Notas sobre tamaños

- GitHub permite repos de 40 MB sin problema (límite por archivo ~100 MB). Si tienes binarios grandes, comprime/optimiza o usa Git LFS (evita Netlify Large Media).  
- El despliegue aquí es **local → Netlify CLI**, no depende de LFS del lado de Netlify.

---

## Archivo `_redirects` de Netlify (incluido)

```
/calculadora/*    /:splat    200
/*                /index.html 200
```

---

## Soporte de stacks detectados

- **Vite** → `vite.config.{js,ts}` → `base: '/calculadora/'`
- **CRA** → `package.json.homepage = 'https://fonasapad.cl/calculadora'`
- **Next.js** → `next.config.{js,ts} -> basePath: '/calculadora', assetPrefix: '/calculadora/'` (para export estático, usa `next export` → `out/`)
- **Vue CLI** → `vue.config.js -> publicPath: '/calculadora/'`
- **Angular** → `angular.json -> baseHref/deployUrl: '/calculadora/'`

---

## ¿Qué cambia en el contenido?

- Hero: **Texto exacto** que solicitaste.  
- Se eliminan archivos/refs al **Dr. Nasser** (Eluzen/Eluzem) de código y `assets/` (si existen).  
- Menú en `fonasapad`: “CONTACTO” → “Calculadora PAD” (`/calculadora/`).

---

## Si algo no se detecta automáticamente…

- El script no hace cambios “ciegos” destructivos. Te mostrará candidatos y necesitarás confirmar/editar a mano en casos raros.  
- Repite el comando después de corregir; el proceso es **idempotente** (no duplica cambios).

¡Éxitos!
