/**
 * Cloudflare Worker para publicar la calculadora bajo /calculadora/* en fonasapad.cl
 * Proxy: fonasapad.cl/calculadora/*  ->  https://<TU-SITIO-NETLIFY>.netlify.app/*
 * IMPORTANTE: Cambia UPSTREAM por tu dominio Netlify.
 */
const UPSTREAM = 'https://<TU-SITIO-NETLIFY>.netlify.app'; // <- AJUSTAR

export default {
  async fetch(request) {
    const url = new URL(request.url);

    if (url.pathname.startsWith('/calculadora')) {
      const newPath = url.pathname.replace(/^\/calculadora/, '') || '/';
      const target = new URL(newPath + url.search, UPSTREAM);

      const init = {
        method: request.method,
        headers: new Headers(request.headers),
        body: request.method !== 'GET' && request.method !== 'HEAD' ? await request.blob() : undefined,
      };
      init.headers.set('host', new URL(UPSTREAM).hostname);

      const resp = await fetch(target, init);
      return new Response(resp.body, { status: resp.status, headers: resp.headers });
    }

    return fetch(request);
  }
}
