/**
 * patch-config.mjs
 * Detecta stack (Vite/CRA/Next/Vue/Angular) y ajusta base path a '/calculadora/'.
 * Uso: node patch-config.mjs <ruta_proyecto> <basePath>
 */
import { readFileSync, writeFileSync, existsSync } from 'fs';
import { join } from 'path';

const root = process.argv[2];
const basePath = process.argv[3] || '/calculadora/';

if (!root) {
  console.error('Uso: node patch-config.mjs <ruta_proyecto> <basePath>');
  process.exit(1);
}

function tryWrite(file, content) {
  writeFileSync(file, content, 'utf-8');
  console.log('  -> modificado:', file);
}

function patchVite() {
  const files = ['vite.config.js', 'vite.config.ts'].map(f => join(root, f));
  for (const f of files) {
    if (existsSync(f)) {
      let s = readFileSync(f, 'utf-8');
      if (!/base\s*:\s*['"]\/.+['"]/.test(s)) {
        s = s.replace(/defineConfig\(\{?/, (m) => `${m}\n  base: '${basePath}',`);
      } else {
        s = s.replace(/base\s*:\s*['"][^'"]+['"]/, `base: '${basePath}'`);
      }
      tryWrite(f, s);
      return true;
    }
  }
  return false;
}

function patchCRA() {
  const pkgFile = join(root, 'package.json');
  if (existsSync(pkgFile)) {
    const pkg = JSON.parse(readFileSync(pkgFile, 'utf-8'));
    if ((pkg.dependencies && (pkg.dependencies.react || pkg.dependencies['react-scripts'])) || (pkg.devDependencies && pkg.devDependencies['react-scripts'])) {
      pkg.homepage = 'https://fonasapad.cl' + basePath.replace(/\/$/, '');
      tryWrite(pkgFile, JSON.stringify(pkg, null, 2) + '\n');
      return true;
    }
  }
  return false;
}

function patchNext() {
  const files = ['next.config.js', 'next.config.mjs', 'next.config.ts'];
  for (const name of files) {
    const f = join(root, name);
    if (existsSync(f)) {
      let s = readFileSync(f, 'utf-8');
      if (!/basePath\s*:/.test(s)) {
        s = s.replace(/module\.exports\s*=\s*\{?/, m => `${m}\n  basePath: '${basePath.replace(/\/$/, '')}',\n  assetPrefix: '${basePath}',`);
      } else {
        s = s.replace(/basePath\s*:\s*['"][^'"]+['"]/, `basePath: '${basePath.replace(/\/$/, '')}'`);
        if (/assetPrefix\s*:/.test(s)) {
          s = s.replace(/assetPrefix\s*:\s*['"][^'"]+['"]/, `assetPrefix: '${basePath}'`);
        } else {
          s = s.replace(/basePath[^\n]*\n/, (m) => m + `  assetPrefix: '${basePath}',\n`);
        }
      }
      tryWrite(f, s);
      return true;
    }
  }
  return false;
}

function patchVueCLI() {
  const f = join(root, 'vue.config.js');
  if (existsSync(f)) {
    let s = readFileSync(f, 'utf-8');
    if (!/publicPath\s*:/.test(s)) {
      if (/module\.exports\s*=\s*\{/.test(s)) {
        s = s.replace(/module\.exports\s*=\s*\{/, m => `${m}\n  publicPath: '${basePath}',`);
      } else {
        s += `\nmodule.exports = {{ publicPath: '${basePath}' }}\n`.replace('{{','{');
      }
    } else {
      s = s.replace(/publicPath\s*:\s*['"][^'"]+['"]/, `publicPath: '${basePath}'`);
    }
    tryWrite(f, s);
    return true;
  }
  return false;
}

function patchAngular() {
  const f = join(root, 'angular.json');
  if (existsSync(f)) {
    let s = readFileSync(f, 'utf-8');
    s = s.replace(/"baseHref"\s*:\s*".*?"/g, `"baseHref": "${basePath}"`);
    if (!/"baseHref"/.test(s)) {
      s = s.replace(/"options"\s*:\s*\{/, (m) => `${m}\n        "baseHref": "${basePath}",`);
    }
    s = s.replace(/"deployUrl"\s*:\s*".*?"/g, `"deployUrl": "${basePath}"`);
    if (!/"deployUrl"/.test(s)) {
      s = s.replace(/"baseHref"[^\n]*\n/, (m) => m + `        "deployUrl": "${basePath}",\n`);
    }
    tryWrite(f, s);
    return true;
  }
  return false;
}

const ok = patchVite() || patchCRA() || patchNext() || patchVueCLI() || patchAngular();
if (!ok) console.warn('No se detectó stack conocido. Edita manualmente el base path.');
