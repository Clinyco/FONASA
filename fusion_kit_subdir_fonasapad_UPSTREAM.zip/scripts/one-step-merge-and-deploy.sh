#!/usr/bin/env bash
set -euo pipefail

# ==== Carga .env si existe ====
if [ -f "../.env" ]; then
  export $(grep -v '^#' ../.env | xargs -I{} echo "{}" | sed 's/\r$//')
fi

# ==== Variables con defaults ====
CALC_REPO_GIT="${CALC_REPO_GIT:-git@github.com:Clinyco/fonasa.git}"
SITE_REPO_GIT="${SITE_REPO_GIT:-git@github.com:Clinyco/fonasapad.git}"
CALC_BRANCH="${CALC_BRANCH:-main}"
SITE_BRANCH="${SITE_BRANCH:-main}"
NETLIFY_SITE_NAME="${NETLIFY_SITE_NAME:-}"

HERO_TEXT="${HERO_TEXT:-Trastorno músculo-esquelético que por dolor crónico requiera una perdida de peso significativa para resolver el dolor o llevar a cabo la cirugía protésica.}"

WORKDIR="$(pwd)/../work"
CALC_DIR="${WORKDIR}/fonasa"
SITE_DIR="${WORKDIR}/fonasapad"

mkdir -p "${WORKDIR}"

echo "=== 1) Clonando repos ==="
rm -rf "${CALC_DIR}" "${SITE_DIR}"
git clone --branch "${CALC_BRANCH}" --depth 1 "${CALC_REPO_GIT}" "${CALC_DIR}"
git clone --branch "${SITE_BRANCH}" --depth 1 "${SITE_REPO_GIT}" "${SITE_DIR}"

echo "=== 2) Ajustando base path de la calculadora a /calculadora/ ==="
node ./patch-config.mjs "${CALC_DIR}" "/calculadora/" || { echo "Patch de base path: revisa manualmente"; }

echo "=== 3) Contenido ==="
echo " - Reemplazo HERO y limpieza Dr. Nasser en CALCULADORA"
bash ./clean-nasser.sh "${CALC_DIR}" "${HERO_TEXT}" || true
echo " - Limpieza Dr. Nasser en SITIO (sin tocar hero)"
SKIP_HERO=1 bash ./clean-nasser.sh "${SITE_DIR}" "${HERO_TEXT}" || true

echo "=== 4) Build de la calculadora ==="
pushd "${CALC_DIR}" >/dev/null
if [ -f package.json ]; then
  if ! command -v npm >/dev/null 2>&1; then
    echo "ERROR: npm no está instalado"; exit 1
  fi
  npm ci || npm install
  if npm run | grep -q "export"; then
    npm run export || true
  fi
  if npm run | grep -q "build"; then
    npm run build
  else
    echo "ERROR: No existe script 'build' en package.json"; exit 1
  fi
else
  echo "ERROR: No hay package.json en la calculadora"; exit 1
fi

# Detecta carpeta de salida
OUT_DIR=""
for d in "dist" "build" "out"; do
  if [ -d "${d}" ]; then OUT_DIR="${d}"; break; fi
done
if [ -z "${OUT_DIR}" ]; then
  echo "ERROR: No encuentro carpeta de salida (dist/build/out)"; exit 1
fi
popd >/dev/null

echo "=== 5) Copiando _redirects a la carpeta de build ==="
cp ../netlify/_redirects "${CALC_DIR}/${OUT_DIR}/_redirects" || true

echo "=== 6) Netlify CLI: login, init y deploy ==="
if ! command -v netlify >/dev/null 2>&1; then
  npm i -g netlify-cli
fi

pushd "${CALC_DIR}" >/dev/null
netlify login

if [ -n "${NETLIFY_SITE_NAME}" ]; then
  netlify init --manual --name "${NETLIFY_SITE_NAME}" || true
else
  netlify init --manual || true
fi

echo "Despliegue draft (preview)..."
netlify deploy --dir="${OUT_DIR}" || true

read -p "¿Desplegar a producción? (y/N): " CONFIRM
if [[ "${CONFIRM:-N}" == "y" || "${CONFIRM:-N}" == "Y" ]]; then
  netlify deploy --prod --dir="${OUT_DIR}"
else
  echo "Puedes publicar luego con: netlify deploy --prod --dir=${OUT_DIR}"
fi
popd >/dev/null

echo "=== 7) (Opcional) Actualizando menú en repo del sitio principal ==="
bash ./update-menu.sh "${SITE_DIR}" || true

echo "=== 8) Worker de Cloudflare ==="
echo " - UPSTREAM preconfigurado en cloudflare/worker-calculadora.js"
echo " - Crea la Route: fonasapad.cl/calculadora*"

echo "=== 9) RESUMEN ==="
cat <<EOF

- Calculadora compilada en: ${CALC_DIR}/${OUT_DIR}
- Desplegada con Netlify CLI (revisa los links en consola)
- Proxy por subdirectorio:
    * Publica el Worker 'cloudflare/worker-calculadora.js'
    * Ruta: fonasapad.cl/calculadora*
    * UPSTREAM actual: {UPSTREAM}

EOF

echo "Todo listo."
