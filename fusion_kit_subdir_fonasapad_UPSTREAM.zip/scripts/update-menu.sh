#!/usr/bin/env bash
set -euo pipefail
SITE="${1:-}"
if [ -z "${SITE}" ] || [ ! -d "${SITE}" ]; then
  echo "Uso: update-menu.sh <ruta_repo_sitio>"; exit 0
fi

echo "-> Cambiando CONTACTO -> Calculadora PAD (/calculadora/) en archivos comunes del menú"
pushd "${SITE}" >/dev/null
grep -RIl --include='*.{html,htm,js,jsx,ts,tsx,vue}' -e 'CONTACTO' -e 'Contacto' -e 'contacto' . | while read -r f; do
  sed -i.bak 's/>\s*CONTACTO\s*</>Calculadora PAD</g;s/>\s*Contacto\s*</>Calculadora PAD</g;s/>\s*contacto\s*</>Calculadora PAD</g' "$f" || true
  sed -i.bak 's/href=["'\''"]\/?contacto\/?["'\''"]/href="\/calculadora\/"/g' "$f" || true
done
popd >/dev/null
