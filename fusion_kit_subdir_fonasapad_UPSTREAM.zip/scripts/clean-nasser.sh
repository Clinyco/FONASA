#!/usr/bin/env bash
set -euo pipefail
# Uso: clean-nasser.sh <ruta_proyecto> "<TEXTO_HERO>"
PROJ="${1:-}"
HERO_TEXT="${2:-}"
SKIP_HERO="${SKIP_HERO:-0}"

if [ -z "${PROJ}" ] || [ -z "${HERO_TEXT}" ]; then
  echo "Uso: clean-nasser.sh <ruta_proyecto> \"<TEXTO_HERO>\""
  exit 1
fi
if [ ! -d "${PROJ}" ]; then
  echo "Ruta no válida: ${PROJ}"; exit 1
fi

pushd "${PROJ}" >/dev/null

echo "-> Eliminando materiales del Dr. Nasser (Eluzen/Eluzem) si existen..."
shopt -s nullglob nocaseglob
for f in assets/*Nasser*.webp assets/*Nasser*.png assets/*Nasser*.jpg assets/*Nasser*.jpeg; do
  echo "   borrando ${f}"; rm -f "${f}" || true
done
shopt -u nocaseglob

# Quitar referencias textuales comunes
grep -RIl --include='*.{html,htm,js,jsx,ts,tsx,vue,svelte,css,scss,md}' -e 'Nasser' -e 'Eluzen' -e 'Eluzem' -e 'Cirujano Bari' . | while read -r file; do
  sed -i.bak '/Nasser/d;/Eluzen/d;/Eluzem/d;/Cirujano Bari/d' "$file" || true
done

if [ "${SKIP_HERO}" != "1" ]; then
  echo "-> Intentando insertar/actualizar texto de HERO en la calculadora..."
  CAND=$(grep -RIl --include='*.{html,htm,js,jsx,ts,tsx,vue,svelte}' -e 'id=["'\''"]hero["'\''"]' -e 'class=["'\''"]hero["'\''"]' . | head -n 1 || true)
  if [ -n "${CAND}" ]; then
    if ! grep -q "hero-overlay" "${CAND}"; then
      perl -0777 -pe 's#(</section>|</div>)#<div class="hero-overlay">'"${HERO_TEXT//\//\\/}"'</div>\n\1#i' -i.bak "${CAND}" || true
      for css in src/styles.css src/main.css styles.css public/styles.css; do
        if [ -f "$css" ]; then
          cat >> "$css" <<'CSS'
.hero { position: relative; }
.hero .hero-overlay {
  position: absolute; inset: 0; display: grid; place-items: center;
  padding: 1.25rem; text-align: center; font-weight: 600;
  font-size: clamp(1rem, 2vw, 1.25rem);
}
CSS
          break
        fi
      done
    fi
  else
    echo "   No se detectó hero automáticamente. Edita manualmente si es necesario."
  fi
fi

popd >/dev/null
