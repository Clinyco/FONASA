# FONASA / FONASAPAD — Fusión por subdirectorio `/calculadora/` (UPSTREAM preconfigurado)

Este kit está **preconfigurado** para usar como **UPSTREAM** de la calculadora:
- **https://690ecc088529e739d3cec250--fonasapadcl.netlify.app**

Se integra por **subdirectorio** (Opción B):
- La calculadora se sirve bajo **https://fonasapad.cl/calculadora/** usando **Cloudflare Worker** como proxy → upstream Netlify (arriba).
- La calculadora se compila localmente con base **`/calculadora/`** y se despliega con **Netlify CLI**.
- Se reemplaza el **texto del hero** de la calculadora y se **elimina** material del **Dr. Nasser** (Eluzen/Eluzem).
- (Opcional) Se actualiza el **menú** del sitio `fonasapad` (CONTACTO → “Calculadora PAD” → `/calculadora/`).

> ⚠️ Recomendado: en Netlify, configura un dominio **estable** (por ej. `https://fonasapadcl.netlify.app` o un custom como `https://calculadora.fonasapad.cl`) y luego **cambia** la constante `UPSTREAM` del Worker a ese dominio estable. Los subdominios con hash son propios de *deploy previews* y pueden cambiar.

## Uso en **un paso**
```bash
cd scripts
bash one-step-merge-and-deploy.sh
```
- Clona `fonasa` y `fonasapad` (rama `main` por defecto).
- Ajusta **base path** `/calculadora/` según el stack (Vite/CRA/Next/Vue/Angular).
- Sustituye el **hero** de la calculadora por el texto indicado.
- Elimina materiales del **Dr. Nasser** en ambos repos (no toca el hero del sitio principal).
- Compila la calculadora → genera `dist/` (o `build/`/`out/`).
- Asegura `netlify/_redirects` en la raíz de la build.
- Despliega con **Netlify CLI** (draft y opción de prod).
- (Opcional) Actualiza el menú del repo `fonasapad` (CONTACTO → Calculadora PAD).
- Muestra recordatorio para publicar el **Worker** (ya preconfigurado con UPSTREAM).

## Variables (.env opcional)
Copia `.env.example` a `.env` y ajusta si hace falta:
```
CALC_REPO_GIT=git@github.com:Clinyco/fonasa.git
SITE_REPO_GIT=git@github.com:Clinyco/fonasapad.git
CALC_BRANCH=main
SITE_BRANCH=main
NETLIFY_SITE_NAME=fonasapad-calculadora
HERO_TEXT=Trastorno músculo-esquelético que por dolor crónico requiera una perdida de peso significativa para resolver el dolor o llevar a cabo la cirugía protésica.
```

## Netlify `_redirects`
Se copia automáticamente a la carpeta de build:
```
/calculadora/*    /:splat    200
/*                /index.html 200
```

## Publicar Cloudflare Worker
- Archivo: `cloudflare/worker-calculadora.js` (ya con **UPSTREAM** = https://690ecc088529e739d3cec250--fonasapadcl.netlify.app)
- Crea la **Route**: `fonasapad.cl/calculadora*` → este Worker.
- Cuando tengas un dominio estable en Netlify, edita `UPSTREAM` y vuelve a publicar el Worker.

