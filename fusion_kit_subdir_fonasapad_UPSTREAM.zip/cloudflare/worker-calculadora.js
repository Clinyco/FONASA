/**
 * Cloudflare Worker: /calculadora/* -> UPSTREAM (Netlify) 
 * UPSTREAM (preconfigurado): https://690ecc088529e739d3cec250--fonasapadcl.netlify.app
 * Recomendación: usar dominio estable de Netlify para producción.
 */
const UPSTREAM = 'https://690ecc088529e739d3cec250--fonasapadcl.netlify.app';

export default {
  async fetch(request) {
    const url = new URL(request.url);
    if (url.pathname.startsWith('/calculadora')) {
      const newPath = url.pathname.replace(/^\/calculadora/, '') || '/';
      const target = new URL(newPath + url.search, UPSTREAM);
      const init = {
        method: request.method,
        headers: new Headers(request.headers),
        body: request.method !== 'GET' && request.method !== 'HEAD' ? await request.blob() : undefined,
      };
      init.headers.set('host', new URL(UPSTREAM).hostname);
      const resp = await fetch(target, init);
      return new Response(resp.body, { status: resp.status, headers: resp.headers });
    }
    return fetch(request);
  }
};
